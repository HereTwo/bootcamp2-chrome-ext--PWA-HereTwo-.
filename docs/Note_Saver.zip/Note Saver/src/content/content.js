for(const a of document.querySelectorAll('a')){
  a.style.outline='2px dashed #ffb86b';
}